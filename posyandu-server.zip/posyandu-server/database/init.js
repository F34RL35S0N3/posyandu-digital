const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');

const dbPath = path.join(__dirname, 'posyandu.db');
const db = new sqlite3.Database(dbPath);

console.log('🔧 Initializing Posyandu Database...');

// Create tables
db.serialize(() => {
    // Users/Petugas table
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            nama TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            noTelp TEXT,
            jabatan TEXT DEFAULT 'Petugas',
            alamat TEXT,
            status TEXT DEFAULT 'Aktif',
            tanggalBergabung DATETIME DEFAULT CURRENT_TIMESTAMP,
            lastLogin DATETIME,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) console.error('Error creating users table:', err);
        else console.log('✅ Users table created');
    });

    // Babies table
    db.run(`
        CREATE TABLE IF NOT EXISTS babies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            tanggalLahir DATE NOT NULL,
            jenisKelamin TEXT NOT NULL,
            alamat TEXT NOT NULL,
            namaOrtu TEXT NOT NULL,
            noTelp TEXT NOT NULL,
            status TEXT DEFAULT 'Aktif',
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) console.error('Error creating babies table:', err);
        else console.log('✅ Babies table created');
    });

    // Measurements table
    db.run(`
        CREATE TABLE IF NOT EXISTS measurements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            babyId INTEGER NOT NULL,
            userId INTEGER NOT NULL,
            berat REAL NOT NULL,
            tinggi REAL NOT NULL,
            tanggalUkur DATETIME DEFAULT CURRENT_TIMESTAMP,
            catatan TEXT,
            status TEXT DEFAULT 'Normal',
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (babyId) REFERENCES babies (id),
            FOREIGN KEY (userId) REFERENCES users (id)
        )
    `, (err) => {
        if (err) console.error('Error creating measurements table:', err);
        else console.log('✅ Measurements table created');
    });

    // Insert sample data
    console.log('📝 Inserting sample data...');

    // Insert default admin user
    const adminPassword = bcrypt.hashSync('poltek23', 10);
    db.run(`
        INSERT OR REPLACE INTO users (id, username, password, nama, email, jabatan, alamat, noTelp)
        VALUES (1, 'posyandu22', ?, 'Dr. Sari Wijaya', 'admin@posyandu.id', 'Kepala Posyandu', 'Jl. Kesehatan No. 123, Jakarta Selatan', '081234567890')
    `, [adminPassword]);

    // Insert sample staff
    const staffPassword = bcrypt.hashSync('petugas123', 10);
    db.run(`
        INSERT OR IGNORE INTO users (username, password, nama, email, jabatan, alamat, noTelp)
        VALUES ('petugas01', ?, 'Budi Santoso', 'budi@posyandu.id', 'Petugas', 'Jl. Mawar No. 45, Jakarta Timur', '081234567891')
    `, [staffPassword]);

    db.run(`
        INSERT OR IGNORE INTO users (username, password, nama, email, jabatan, alamat, noTelp)
        VALUES ('petugas02', ?, 'Rina Melati', 'rina@posyandu.id', 'Bidan', 'Jl. Melati No. 67, Jakarta Barat', '081234567892')
    `, [staffPassword]);

    // Insert sample babies
    const babies = [
        ['Ahmad Fauzi', '2023-03-15', 'Laki-laki', 'Jl. Anggrek No. 12, Jakarta', 'Ibu Siti Aminah', '081234567893'],
        ['Sari Indah', '2023-05-20', 'Perempuan', 'Jl. Kenanga No. 34, Jakarta', 'Ibu Dewi Sartika', '081234567894'],
        ['Budi Kecil', '2023-01-10', 'Laki-laki', 'Jl. Cempaka No. 56, Jakarta', 'Ibu Ratna Sari', '081234567895'],
        ['Maya Cantik', '2023-07-08', 'Perempuan', 'Jl. Dahlia No. 78, Jakarta', 'Ibu Lestari', '081234567896'],
        ['Andi Putra', '2023-04-25', 'Laki-laki', 'Jl. Flamboyan No. 90, Jakarta', 'Ibu Sri Wahyuni', '081234567897']
    ];

    babies.forEach((baby, index) => {
        db.run(`
            INSERT OR IGNORE INTO babies (nama, tanggalLahir, jenisKelamin, alamat, namaOrtu, noTelp)
            VALUES (?, ?, ?, ?, ?, ?)
        `, baby);
    });

    // Insert sample measurements
    const measurements = [
        [1, 1, 7.2, 65.5, '2024-01-15 10:00:00', 'Pertumbuhan normal', 'Normal'],
        [1, 1, 7.8, 67.0, '2024-02-15 10:00:00', 'Berat naik sesuai target', 'Normal'],
        [1, 1, 8.3, 68.5, '2024-03-15 10:00:00', 'Sehat dan aktif', 'Normal'],
        [2, 2, 6.8, 63.0, '2024-01-20 11:00:00', 'Perkembangan baik', 'Normal'],
        [2, 2, 7.4, 64.5, '2024-02-20 11:00:00', 'Appetite baik', 'Normal'],
        [3, 1, 8.5, 69.0, '2024-01-10 09:00:00', 'Sedikit lebih berat dari rata-rata', 'Normal'],
        [3, 1, 9.1, 70.5, '2024-02-10 09:00:00', 'Pertumbuhan cepat', 'Normal'],
        [4, 2, 6.5, 62.0, '2024-02-08 14:00:00', 'Berat sedikit kurang', 'Kurang'],
        [4, 2, 7.0, 63.5, '2024-03-08 14:00:00', 'Sudah membaik', 'Normal'],
        [5, 1, 7.9, 67.5, '2024-02-25 15:00:00', 'Sehat dan ceria', 'Normal']
    ];

    measurements.forEach((measurement) => {
        db.run(`
            INSERT OR IGNORE INTO measurements (babyId, userId, berat, tinggi, tanggalUkur, catatan, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `, measurement);
    });

    console.log('✅ Sample data inserted successfully');
});

db.close((err) => {
    if (err) {
        console.error('❌ Error closing database:', err.message);
    } else {
        console.log('🎉 Database initialization completed!');
        console.log('📊 Database location:', dbPath);
        console.log('🔐 Default admin login:');
        console.log('   Username: posyandu22');
        console.log('   Password: poltek23');
    }
});
