import React, { useState, useEffect } from 'react';
import { authAPI } from './services/api';
import AuthPage from './components/AuthPage';
import Dashboard from './components/Dashboard';
import DataBayi from './components/DataBayi';
import Pengukuran from './components/Pengukuran';
import DataPetugas from './components/DataPetugas';

function App() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [currentUser, setCurrentUser] = useState(null);
    const [currentPage, setCurrentPage] = useState('dashboard');

    // Check if user is already logged in
    useEffect(() => {
        const savedUser = authAPI.getCurrentUser();
        const token = localStorage.getItem('posyandu_token');
        
        if (savedUser && token) {
            setCurrentUser(savedUser);
            setIsAuthenticated(true);
        }
    }, []);

    const handleLogin = (user) => {
        // This function receives user data from AuthPage after successful API login
        console.log('handleLogin called with user:', user); // Debug log
        setCurrentUser(user);
        setIsAuthenticated(true);
        setCurrentPage('dashboard');
        console.log('State updated - isAuthenticated:', true); // Debug log
    };

    const handleLogout = () => {
        authAPI.logout();
        setIsAuthenticated(false);
        setCurrentUser(null);
        setCurrentPage('dashboard');
    };

    const handleNavigate = (page) => {
        setCurrentPage(page);
    };

    const handleBack = () => {
        setCurrentPage('dashboard');
    };

    if (!isAuthenticated) {
        return <AuthPage onLogin={handleLogin} />;
    }

    const renderCurrentPage = () => {
        switch (currentPage) {
            case 'dashboard':
                return (
                    <Dashboard 
                        user={currentUser} 
                        onLogout={handleLogout} 
                        onNavigate={handleNavigate} 
                    />
                );
            case 'data-bayi':
                return (
                    <DataBayi 
                        onNavigate={handleNavigate} 
                        onBack={handleBack} 
                    />
                );
            case 'pengukuran':
                return (
                    <Pengukuran 
                        onBack={handleBack} 
                    />
                );
            case 'data-petugas':
                return (
                    <DataPetugas 
                        onBack={handleBack} 
                        currentUser={currentUser} 
                    />
                );
            case 'laporan':
                return (
                    <div style={{ 
                        minHeight: '100vh', 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'center',
                        background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
                        fontFamily: 'Inter, sans-serif'
                    }}>
                        <div style={{
                            background: 'white',
                            padding: '3rem',
                            borderRadius: '20px',
                            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.1)',
                            textAlign: 'center',
                            maxWidth: '500px'
                        }}>
                            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>📊</div>
                            <h2 style={{ color: '#2d3748', marginBottom: '1rem' }}>Fitur Laporan</h2>
                            <p style={{ color: '#718096', marginBottom: '2rem' }}>
                                Fitur laporan dan cetak PDF sedang dalam pengembangan.
                                Akan segera tersedia dalam versi berikutnya!
                            </p>
                            <button 
                                onClick={handleBack}
                                style={{
                                    padding: '12px 24px',
                                    background: 'linear-gradient(135deg, #667eea, #764ba2)',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '12px',
                                    cursor: 'pointer',
                                    fontWeight: '600',
                                    transition: 'all 0.3s ease'
                                }}
                                onMouseOver={(e) => {
                                    e.target.style.transform = 'translateY(-2px)';
                                    e.target.style.boxShadow = '0 8px 25px rgba(102, 126, 234, 0.3)';
                                }}
                                onMouseOut={(e) => {
                                    e.target.style.transform = 'translateY(0)';
                                    e.target.style.boxShadow = 'none';
                                }}
                            >
                                ← Kembali ke Dashboard
                            </button>
                        </div>
                    </div>
                );
            default:
                return (
                    <Dashboard 
                        user={currentUser} 
                        onLogout={handleLogout} 
                        onNavigate={handleNavigate} 
                    />
                );
        }
    };

    return (
        <div className="App">
            {renderCurrentPage()}
        </div>
    );
}

export default App;